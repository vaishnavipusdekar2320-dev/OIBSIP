# Task 2 — Random Password Generator

## Overview
A beginner-friendly Python command-line program that generates a random password using uppercase letters, lowercase letters, numbers, and punctuation symbols. It validates the requested length before generating the password.

## Requirements
- Python 3.8 or newer
- No third-party packages required

## How to run
1. Install Python if it is not already installed.
2. Open a terminal or command prompt in this folder.
3. Run:

   ```bash
   python password_generator.py
   ```

   On some systems, use `python3 password_generator.py`.

4. Enter a password length between 8 and 128 when prompted.
5. Copy the generated password somewhere safe if you need it. Do not share real passwords publicly.

## Features
- Uses Python's `secrets` module for secure random choices.
- Includes letters, numbers, and symbols.
- Rejects non-numeric input and lengths outside the allowed range.
- Prints the generated password and its length.

## Example run
```text
=== Random Password Generator ===
Enter password length (minimum 8): 12

Your generated password is:
(example output will vary)
Length: 12 characters
```

## Files
- `password_generator.py` — program source code.

## What I learned
- Using Python functions and loops.
- Validating user input with `try`/`except`.
- Working with the `string` and `secrets` modules.
