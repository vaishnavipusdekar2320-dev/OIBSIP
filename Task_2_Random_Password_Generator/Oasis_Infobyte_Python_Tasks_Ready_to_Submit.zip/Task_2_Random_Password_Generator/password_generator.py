import secrets
import string


def generate_password(length):
    """Return a secure random password containing letters, digits, and symbols."""
    characters = string.ascii_letters + string.digits + string.punctuation
    return "".join(secrets.choice(characters) for _ in range(length))


def main():
    print("=== Random Password Generator ===")

    while True:
        try:
            length = int(input("Enter password length (minimum 8): "))
            if length < 8:
                print("Please enter a length of at least 8 characters.")
                continue
            if length > 128:
                print("Please choose a length of 128 characters or fewer.")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter a whole number.")

    password = generate_password(length)
    print("\nYour generated password is:")
    print(password)
    print(f"Length: {len(password)} characters")


if __name__ == "__main__":
    main()
