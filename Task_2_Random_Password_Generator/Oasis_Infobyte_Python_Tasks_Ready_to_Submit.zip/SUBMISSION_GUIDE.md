# OIB-SIP Python Internship — Submission Checklist

You stated that the internship requires at least three Python tasks. You already have a calculator task; these folders contain a Random Password Generator and a Basic Weather App as two additional tasks.

## Before submitting
- [ ] Run your Calculator project and keep its source code and README.
- [ ] Run `password_generator.py` and test valid and invalid lengths.
- [ ] Install `requests`, set your own OpenWeatherMap API key privately, and test `weather_app.py`.
- [ ] Add screenshots showing each program running successfully.
- [ ] Create a public GitHub repository for your internship tasks, or use the repository format specified by your coordinator.
- [ ] Upload each task's source code and README. Do not upload API keys or passwords.
- [ ] Copy the correct public GitHub repository link for the submission form.
- [ ] Complete the form before the stated deadline and follow the current instructions from your internship coordinator.

## Suggested GitHub repository layout
```text
OIB-SIP-Python-Programming/
├── Task_1_Calculator/
│   ├── calculator.py
│   ├── README.md
│   └── screenshots/
├── Task_2_Random_Password_Generator/
│   ├── password_generator.py
│   ├── README.md
│   └── screenshots/
└── Task_3_Basic_Weather_App/
    ├── weather_app.py
    ├── requirements.txt
    ├── README.md
    └── screenshots/
```

## Important
This ZIP is a starter submission package for Tasks 2 and 3. Add your own screenshots after running the projects, and add your existing calculator files. Review the exact form fields and instructions before submitting. Never claim you tested a program unless you have run it yourself.
